# Anthony Garcia-Fernandez
# CTI 110 - P4LAB1b
# Turtle Graphics - Initials
# Date: November 19, 2024
# This program draws my initials (A and G) using turtle graphics.

import turtle

# Setup turtle
t = turtle.Turtle()
t.pensize(3)  # Set pen size
t.pencolor("blue")  # Set pen color

# Draw 'A'
t.penup()
t.goto(-100, 0)  # Adjust starting position
t.pendown()
t.left(75)
t.forward(100)
t.right(150)
t.forward(100)
t.backward(50)
t.right(105)
t.forward(30)

# Move to position for 'G'
t.penup()
t.goto(50, 0)  # Adjust position for the next letter
t.setheading(0)  # Reset heading
t.pendown()

# Draw 'G'
t.circle(50, 270)  # Draw an arc
t.left(90)
t.forward(30)

# End the program
turtle.done()

