# Anthony Garcia-Fernandez
# CTI 110 - P4LAB1a
# Turtle Graphics - Shapes
# Date: November 19, 2024
# This program draws a square and a triangle using loops.

import turtle

# Setup turtle
t = turtle.Turtle()

# Draw a square
for _ in range(4):
    t.forward(100)  # Adjust the side length as needed
    t.right(90)

# Move turtle to start position for triangle
t.penup()
t.goto(-150, 0)  # Adjust starting position
t.pendown()

# Draw a triangle
for _ in range(3):
    t.forward(100)
    t.right(120)

# End the program
turtle.done()

