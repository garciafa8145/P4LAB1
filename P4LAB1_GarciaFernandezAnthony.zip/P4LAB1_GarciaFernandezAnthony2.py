import turtle

# Function to draw a triangle
def draw_triangle(side_length):
    for _ in range(3):
        turtle.forward(side_length)
        turtle.right(120)

# Set up the turtle
turtle.speed(2)  # Set the drawing speed
turtle.color("red")  # Set color for the triangle

# Move the turtle to a new position for the triangle
turtle.penup()
turtle.goto(-50, -100)  # Move to a new position
turtle.pendown()

# Draw the triangle
draw_triangle(100)  # You can change the size by modifying this value

# Finish drawing
turtle.done()
